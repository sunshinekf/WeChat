// app.js
App({
  onLaunch: function () {
    //云开发环境的初始化
    wx.cloud.init({
      env: 'test-306h7'
    })
  },
  globalData: {
    userInfo: null
  }
})

