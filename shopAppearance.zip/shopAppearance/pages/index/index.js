// index.js
// 获取应用实例

