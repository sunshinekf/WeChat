Page({
  data:{
    //隐藏或显示密码判断
    isShow1:true,
    inputType1:"password",
    newPassword:"",
    //输入数据
    name:"",
    password:"",
    //输出用户id
    yourID:"",

    disable:true,

    datalist:[]
    },

  onLoad:function(options){

      this.setData({

      })
  },
    //显示密码的输入框
    seePassword:function(e){
      this.setData({
        newPassword:e.detail.value
      })
    },
    //隐藏密码的输入框
    hidePassword(e){
      this.setData({
        newPassword:e.detail.value
      })
    },
    //点击小眼睛图标
    openeyes:function(){
        if(this.data.isShow1){
          this.setData({
            isShow1:false,
            inputType1:"text"
          })

        }else{
          this.setData({
            isShow1:true,
            inputType1:"password"
          })
        }
    },

  //存储用户名输入框输入的数据
    getName(event) {
        this.setData({
          name : event.detail.value,
          disable: false
        })  
    },
  //存储密码输入框输入的数据
    seePassword(event) {
      this.setData({
        password : event.detail.value
      }) 
    },
    hidePassword(event) {
      this.setData({
        password : event.detail.value
      }) 
    },
//点击登录按钮
  login:function(){
    //that全局，把上方的datalist包含进去
    let that = this
    let name = this.data.name
    let password = this.data.password
    console.log('用户名', name, '密码', password)
    if (name.length < 2) {
      wx.showToast({
        icon: 'none',
        title: '用户名至少2位',
      })
      return
    }
    if (password.length < 3) {
      wx.showToast({
        icon: 'none',
        title: '密码至少3位',
      })
      return
  }
  //登录
  wx.cloud.database().collection('user').get({
    success:res =>{
      console.log("获取数据成功", res)
      that.setData({
        datalist:res.data
      })
     // console.log(this.data.datalist)
    for (var i = 0; i < this.data.datalist.length-1; i++) {
        if (this.data.name==this.data.datalist[i].name) {
          if(this.data.password==this.data.datalist[i].password){
            console.log('登陆成功')
            that.setData({
              yourID:this.data.datalist[i]._id
            })
            wx.showToast({
              title: '登陆成功',
            })
    
          //跳转页面
           wx.navigateTo({
            url: '/pages/01shouye/goods/goodType?yourID='+this.data.yourID,
           })
    
          //保存用户登陆状态
          wx.setStorageSync('user', user)
          }
               
        }
        else {
          console.log('登陆失败')
          wx.showToast({
            icon: 'none',
            title: '用户名或密码不正确',
          })
        }
      }
    },
  fail:res =>{
   console.log("获取数据失败", res)
  }
})
  
},
jumpPage1: function () //返回
{
  wx.navigateTo({
    url: '/pages/01shouye/BeforelogIn'
  })
},
  jumpPage2: function () 
{
  wx.navigateTo({
    url: '/pages/01shouye/code/getCode',
  })
},
 jumpPage3: function () 
{
  wx.navigateTo({
    url: '/pages/01shouye/code/findcode',
  })
}
})