// pages/01shouye/code/findcode.js
Page({
  data:{
    //输入的数据
    name:"",
    //查找的数据
    datalist:[],
    password:""
    },

  onLoad:function(options){

      this.setData({

      })
  },

  //存储用户名输入框输入的数据
    findName(event) {
      this.setData({
        name : event.detail.value
      })    
    },

//点击查找按钮
  find:function(){
    //that全局，把上方的datalist包含进去
    let that = this
    let name = this.data.name
    //查找
  wx.cloud.database().collection('user').get({
    success:res =>{
      console.log("获取数据成功", res)
      that.setData({
        datalist:res.data,
        password:"无此用户名，请先注册"
      })
    for (var i = 0; i < this.data.datalist.length; i++) {
        if (this.data.name==this.data.datalist[i].name) {
               this.setData({
                 password:this.data.datalist[i].password
               })
        }
        
      }
    },
  fail:res =>{
   console.log("获取数据失败", res)
  }
}) 
},
 
  jumpPage: function () 
  {
    wx.navigateTo({
      url: '/pages/01shouye/logIn',
    })
  }
})
