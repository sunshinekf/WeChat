
// 获取应用实例
const db = wx.cloud.database().collection("user")
let name=""
let password=""

Page({
  data:{
    datalist:[]
    },

  onLoad:function(options){
      this.setData({

      })
  },
  addName(event) {
    name = event.detail.value
  },
  addPassword(event) {
    password = event.detail.value
  },

  register: function () 
  {
     var ifexist=false;
     //that全局，把上方的datalist包含进去
     let that = this
     //查重
     db.get({
      success:res =>{
        console.log("获取数据成功", res)
        that.setData({
          datalist:res.data
        })
        for (var i = 0; i < this.data.datalist.length-1; i++) {
          if (name==this.data.datalist[i].name) {
              ifexist=true
          }
        }
        if(ifexist){
          wx.showToast({
             icon: 'none',
             title: '用户名已存在，请换用户名',
          })
        }
        else{
          db.add({
            data: {
              name: name,
              password: password,
              shopCar: new Array(),
              weight: new Array()
            },
          success:res =>{
            console.log("添加成功", res);
            wx.navigateTo({
              url: '/pages/01shouye/code/registerSuccess',//页面跳转
            })              
          },
          fail:res =>{
            console.log("添加失败", res)
          },
                  
          })
        }
      },
      fail:res =>{
        console.log("获取数据失败", res)
      }
    })
     
     
  }
})