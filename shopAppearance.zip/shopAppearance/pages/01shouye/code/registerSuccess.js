const db = wx.cloud.database().collection("user")
Page({
  data:{

    },

  onLoad:function(options){

      this.setData({

      })
  },

  jumpPage: function () 
  {
    wx.navigateTo({
      url: '/pages/01shouye/logIn',
    })
  }
})
