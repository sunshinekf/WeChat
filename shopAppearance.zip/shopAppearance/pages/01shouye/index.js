// pages/01shouye/index.js
Page({
  jumpPage: function () //进入
{
  wx.navigateTo({
    url: '/pages/01shouye/BeforelogIn',
  })
}
})
