Page({
  data: {
    type:0,
    datalist:[],
    showList:[],
    //传输用户id,商品id
    yourID:"",
    _id:""
  },
  onLoad:function(options){//接收type和用户id  
    this.setData({
      type:options.type,
      yourID:options.yourID
    })
    console.log(options.yourID);
    console.log(this.data.yourID);
    this.getData()
},
getData:function(){
  //that全局，把上方的datalist包含进去
  let that = this
  //中间变量
   var showlist=[];
  //从数据库中直接取数据
  wx.cloud.database().collection("goodList").get({
    success:res =>{
      console.log("请求成功",res)
      that.setData({
        datalist:res.data
      })
      for (var i = 0; i < this.data.datalist.length; i++) {
        if (this.data.type==this.data.datalist[i].goodtype) {
          showlist.push(this.data.datalist[i]); 
        }  
      }
      this.setData({
        showList:showlist
       })
    },
    fail:res =>{
      console.log("请求失败", res)
    }
  })
},
imgchange: function (event) {
  //获取当前item的下标id  通过currentTarget.id
  var id = event.currentTarget.id;
  this.setData({
    _id:this.data.showList[id]._id
   })
  wx.navigateTo({
    url: '/pages/01shouye/goods/goodintroduce?_id='+this.data._id+'&yourID='+this.data.yourID
  })
},
  jumpPage1: function () //返回商品类型页面
  {
    wx.navigateTo({
      url: '/pages/01shouye/goods/goodType?yourID='+this.data.yourID
    })
  },
  jumpPage2: function () //查看购物车，到达购物车页面
  {
    wx.navigateTo({
      url: '/pages/01shouye/shopCar/shopCar?yourID='+this.data.yourID
    })
  },
  jumpPage3: function () //查看商品详细介绍
  {
    wx.navigateTo({
      url: '/pages/01shouye/goods/goodintroduce?_id='+this.data._id+'&yourID='+this.data.yourID
    })
  }
  
})
