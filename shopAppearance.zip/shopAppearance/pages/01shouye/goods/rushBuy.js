// pages/01shouye/goods/rushBuy.js
var app = getApp()
//调用当前时间
var util = require('../../../utils/util.js');    
    
Page({
  data: {
    //倒计时相关数据
    pingData: [
      {
        "id": "1",
        "number": "20",
        "pingTime": "2019-3-28 23:30:00",
        "time": "55267",
        "showList": "false",
      },
      {
        "id": "2",
        "number": "4566",
        "pingTime": "2019-3-28 12:30:00",
        "time": "58934",
        "showList": "false",
      },
      {
        "id": "3",
        "number": "20",
        "pingTime": "2019-3-28 08:30:00",
        "time": "555234",
        "showList": "false",
      }
    ],
    time:"60",

    //判定抢购是否成功
    //ifbuy:false,
    disabled:false,

    //用户id,商品id
    yourID:"",
    _id:"",

    //储存该商品信息
    datalist:[],
    yourSurplus:0,

  },

  onLoad: function (options) {
    var that = this
 
    //倒计时
    that.setData({
      listData: that.data.pingData,
      _id:options._id,
      yourID:options.yourID,
      yourSurplus:options.yourSurplus,
    })
    
    this.setCountDown();
    this.setTimeCount(); 

    
  },
 
  //倒计时
  setTimeCount: function () {
 
    let time = this.data.time
    time--;
    if (time <= 0) {
      time = 0;
    }
    this.setData({
      time: time
    })
    setTimeout(this.setTimeCount, 1000);
  

  },
  setCountDown: function () {
    //设定的抢购结束时间
    var endTime =new Date(2021, 6,7, 17, 27, 0, 0);//(year, month, day, hours, minutes, seconds, milliseconds);
    var nowTime=new Date();//当前时间
    var t=(endTime.getMinutes()-nowTime.getMinutes())*60+(endTime.getSeconds()-nowTime.getSeconds());
    this.setData({
        time:t
    }) 

    let time = 1000;
    let { listData } = this.data;
    let list = listData.map((v, i) => {
      if (v.time <= 0) {
        v.time = 0;
      }
      let formatTime = this.getFormat(v.time);
      v.time -= time;
      v.countDown = `${formatTime.hh}:${formatTime.mm}:${formatTime.ss}`;
      return v;
    })
    this.setData({
      listData: list
    });
    setTimeout(this.setCountDown, time);
  
  },
  /**
  * 格式化时间
  */
  getFormat: function (msec) {
    let ss = parseInt(msec / 1000);
    let ms = parseInt(msec % 1000);
    let mm = 0;
    let hh = 0;
    if (ss > 60) {
      mm = parseInt(ss / 60);
      ss = parseInt(ss % 60);
      if (mm > 60) {
        hh = parseInt(mm / 60);
        mm = parseInt(mm % 60);
      }
    }
    ss = ss > 9 ? ss : `0${ss}`;
    mm = mm > 9 ? mm : `0${mm}`;
    hh = hh > 9 ? hh : `0${hh}`;
    return { ss, mm, hh };
  },
 
buy: function () //立即抢购函数
{
  var change=this.data.yourSurplus-1;
  console.log(change)
  console.log("this.data._id:", this.data._id)

  //更新数据
  wx.cloud.database().collection("goodList").doc(this.data._id).update({
    data: {
      surplus: change
    },
    success:res =>{
      console.log("更新成功", res),
      wx.navigateTo({//跳转到抢购成功页面
        url: '/pages/01shouye/goods/successfulBuy?yourID='+this.data.yourID
      }) 
    },
    fail:res =>{
      console.log("更新失败", res)
    }
    })
  this.setData({
    disabled: true
  })  
},
  jumpPage1: function () //跳转到商品详情页面
  {
    wx.navigateTo({
      url: '/pages/01shouye/goods/goodsdetail?yourID='+this.data.yourID
    })
  },
  jumpPage2: function () //跳转到购物车页面
  {
    wx.navigateTo({
      url: '/pages/01shouye/shopCar/shopCar?yourID='+this.data.yourID
    })
  }
  
})
