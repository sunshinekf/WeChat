// pages/01shouye/goods/rushBuy.js
//const app = getApp()
Page({
  data: {
    //用户id
    yourID:""
  },
  onLoad: function (options) {
    this.setData({
      yourID:options.yourID
    })
    console.log(options.yourID);
  },
  jumpPage: function () //跳转到购物车页面
  {
    wx.navigateTo({
      url: '/pages/01shouye/shopCar/shopCar?yourID='+this.data.yourID//pages/01shouye/shopCar/shopCar.js
    })
  }
  
})
