Page({
  data: {
    type:0,
    //传输用户id
    yourID:"",
  },
  onLoad:function(options){//接收上一界面传过来的用户id 
    this.setData({
      yourID:options.yourID
    })
    console.log(options.yourID);
},
clickcloth: function () //进入衣物详情页面，编号1
{
  this.setData({
    type:1
  })
  wx.navigateTo({
    url: '/pages/01shouye/goods/goodsdetail?type='+this.data.type+'&yourID='+this.data.yourID
  })
},
clickpen: function () //进入文具详情页面，编号2
{
  this.setData({
    type:2
  })
  wx.navigateTo({
    url: '/pages/01shouye/goods/goodsdetail?type='+this.data.type+'&yourID='+this.data.yourID
  })
},
clickbook: function () //进入书籍详情页面，编号3
{
  this.setData({
    type:3
  })
  wx.navigateTo({
    url: '/pages/01shouye/goods/goodsdetail?type='+this.data.type+'&yourID='+this.data.yourID
  })
},
clickfood: function () //进入食物详情页面，编号4
{
  this.setData({
    type:4
  })
  wx.navigateTo({
    url: '/pages/01shouye/goods/goodsdetail?type='+this.data.type+'&yourID='+this.data.yourID
  })
},

  jumpPage: function () //查看购物车，到达购物车页面
  {
    wx.navigateTo({
      url: '/pages/01shouye/shopCar/shopCar?yourID='+this.data.yourID
    })
  }
})