// pages/01shouye/goods/goodintroduce.js
Page({
  data: {
    datalist:[],//用来存储商品介绍信息
    datalist2:[],//用来存储该用户的信息
    yourSurplus:0,//用来储存该商品剩余件数
    showintroduce:"",
    //传输用户id,商品id
    yourID:"",
    _id:"",
    //判定按钮是否生效
    disabled:false,//加入购物车按钮
    disabled2:true,//删除按钮
    ifsurplus:true,//立即购买按钮
    //权重选择滑块
    weight:0
  },
  onLoad:function(options){  
    this.setData({
      _id:options._id,
      yourID:options.yourID
    })
    console.log(options.yourID);
    this.getData1();
    this.getData2();
    this.ifSurplus();
},
getData1:function(){
  //that全局，把上方的datalist包含进去
  let that = this;
  //得到该商品的详情
  wx.cloud.database().collection('goodIntroduce').get({
    success:res =>{
      console.log("请求成功",res);
      console.log(this.data._id);     
      that.setData({
        datalist:res.data
      })
      console.log(this.data.datalist);
      that.setData({
        showintroduce:this.data.datalist[this.data._id].introduce
      })
    },
    fail:res =>{
      console.log("请求失败", res)
    }
  })
},
getData2:function(){
  //that全局
  let that = this;
  var shopcar="";
  //得到该用户的详情
  wx.cloud.database().collection("user").doc(this.data.yourID).get({
    success:res =>{
      console.log("请求成功",res)
      that.setData({
        datalist2:res.data
      })
      shopcar=this.data.datalist2.shopCar;
      for (var i = 0; i < shopcar.length; i++) {
        if (this.data._id==shopcar[i]) {
               this.setData({
                 disabled:true,
                 disabled2:false
               })
        }       
      }     
    },
    fail:res =>{
      console.log("请求失败", res)
    }

  })
},
//滑块移动实现权重的输入
bindChangeFn(event){
  this.setData({
    weight: event.detail.value
  })
  var i = 0;
  var shopcar="";
  shopcar=this.data.datalist2.shopCar; 
  var yourWeight="";
  yourWeight=this.data.datalist2.weight;
  for (var i = 0; i < shopcar.length; i++) {
    if (this.data._id==shopcar[i]) {
      yourWeight[i]=this.data.weight    
    }       
  } 
  wx.cloud.database().collection("user").doc(this.data.yourID).update({
    data: {
      weight:yourWeight//更新权重
    },
    success:res =>{
      console.log("更新成功", res)
    },
    fail:res =>{
      console.log("更新失败", res)
    }
    }) 


},
addInCar: function () //加入购物车函数
{
  var shopcar="";
  shopcar=this.data.datalist2.shopCar;
  shopcar.push(this.data._id)
  var yourWeight="";
  yourWeight=this.data.datalist2.weight;
  yourWeight.push(50)
  wx.cloud.database().collection("user").doc(this.data.yourID).update({
  data: {
    shopCar: shopcar,
    weight:yourWeight//权重默认50%
  },
  success:res =>{
    console.log("更新成功", res)
  },
  fail:res =>{
    console.log("更新失败", res)
  }
  })

},
ifSurplus: function ()//判定按钮是否生效
{
  let that = this;
  var datalist3=[];//用来储存该商品goodList中信息
  wx.cloud.database().collection("goodList").doc(this.data._id).get({
    success:res =>{
      console.log("请求成功",res)
      datalist3=res.data;
      this.setData({
        yourSurplus:datalist3.surplus
      })
      console.log(datalist3.surplus)
      console.log(this.data.yourSurplus)
      if(datalist3.surplus>0)
      {
        this.setData({
          ifsurplus:false
        })
      } 
    },
    fail:res =>{
      console.log("请求失败", res)
    }
  })
},
buy: function () //跳转到立即抢购界面
{
  wx.navigateTo({
    url: '/pages/01shouye/goods/rushBuy?_id='+this.data._id+'&yourID='+this.data.yourID+'&yourSurplus='+this.data.yourSurplus
  })
},
// 删除方法函数
remove: function(array, val) {
  for (var i = 0; i < array.length; i++) {
    if (array[i] == val) {
      array.splice(i, 1);
    }
  }
  return -1;
},
//删除按钮，从购物车中删除商品，若购物车里没有，则不可用
delet: function ()
{
  //that全局
  let that = this;
  var i = 0;
  var shopcar="";
  shopcar=this.data.datalist2.shopCar;
  that.remove(shopcar, this.data._id);
  var yourWeight="";
  yourWeight=this.data.datalist2.weight;  
  for (var i = 0; i < shopcar.length; i++) {
    if (this.data._id==shopcar[i]) {
      that.remove(yourWeight, yourWeight[i]);    
    }       
  }     
   wx.cloud.database().collection("user").doc(this.data.yourID).update({
    data: {
      shopCar: shopcar,
      weight:yourWeight
    },
    success:res =>{
      console.log("更新成功", res)
    },
    fail:res =>{
      console.log("更新失败", res)
    }
    })

},
jumpPage: function () //查看购物车，到达购物车页面
{
  wx.navigateTo({
    url: '/pages/01shouye/shopCar/shopCar?_id='+this.data._id+'&yourID='+this.data.yourID
  })
}
})
