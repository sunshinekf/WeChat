// pages/01shouye/merchant/addGoods.js
// 获取应用实例
const db = wx.cloud.database().collection("goodList")
let _id=""
let name=""
let price=0
let merchant=""
let surplus=0
let goodtype=""
Page({
  data:{
    check1:false,
    check2:false,
    check3:false,
    check4:false
  },
  addName(event) {
    name = event.detail.value
  },
  addPrice(event) {
    price = event.detail.value
  },
  addMerchant(event) {
    merchant = event.detail.value
  },
  addSurplus(event) {
    surplus = event.detail.value
  },
  radiocon1:function(e){  
    this.setData({
     check1: !this.data.check1
     })
     if(this.data.check1){
      goodtype=1
     }
    console.log("用户打勾的是 ",goodtype)
    console.log("用户打勾的是 ",this.data.check)
   },
   radiocon2:function(e){  
    this.setData({
     check2: !this.data.check2
     })
     if(this.data.check2){
      goodtype=2
     }
    console.log("用户打勾的是 ",goodtype)
    console.log("用户打勾的是 ",this.data.check)
   },
   radiocon3:function(e){  
    this.setData({
     check3: !this.data.check3
     })
     if(this.data.check3){
      goodtype=3
     }
    console.log("用户打勾的是 ",goodtype)
    console.log("用户打勾的是 ",this.data.check)
   },
   radiocon4:function(e){  
    this.setData({
     check4: !this.data.check4
     })
     if(this.data.check){
      goodtype=4
     }
    console.log("用户打勾的是 ",goodtype)
    console.log("用户打勾的是 ",this.data.check)
   },
  addData() {
    let that = this;
    var datalist=[];//用来储存goodList中信息
    if(((this.data.check1==true)&&(this.data.check2==false)&&(this.data.check3==false)&&(this.data.check4==false))||((this.data.check2==true)&&(this.data.check1==false)&&(this.data.check3==false)&&(this.data.check4==false))||((this.data.check3==true)&&(this.data.check2==false)&&(this.data.check1==false)&&(this.data.check4==false))||((this.data.check4==true)&&(this.data.check2==false)&&(this.data.check3==false)&&(this.data.check1==false))){
      db.get({
        success:res =>{
          console.log("请求成功",res)
          datalist=res.data;
          _id=datalist.length;
          console.log(_id)
          db.add({
            data: {
              _id:_id,
              name: name,
              goodtype:goodtype,
              price: price,
              merchant:merchant,
              surplus:surplus
            },
            succsee:res =>{
              console.log("添加成功", res)
            },
            fail:res =>{
              console.log("添加失败", res)
            }
          })
        },
        fail:res =>{
          console.log("请求失败", res)
        }
      })
    }
    else{
      wx.showToast({
        icon: 'none',
        title: '商品类型只能选择一个',
     })

    }
  },

  jumpPage: function () 
  {
    wx.navigateTo({
      url: '/pages/01shouye/BeforelogIn'
    })
  }
})
