// pages/01shouye/BeforelogIn.js
Page({

  jumpPage: function () //以用户身份进入
{
  wx.navigateTo({
    url: '/pages/01shouye/logIn',
  })
},
jumpPage2: function () //以商家身份进入
{
  wx.navigateTo({
    url: '/pages/01shouye/merchant/addGoods',
  })
}
})

