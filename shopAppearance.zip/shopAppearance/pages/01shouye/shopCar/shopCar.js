// pages/01shouye/shopCar/shopCar.js
Page({
  data: {
    datalist1:[],//用来存储该用户的信息
    datalist2:[],//用来存储所有商品信息
    showlist:[],//用来存储要显示的信息
    //传输用户id,商品id
    yourID:"",
    _id:""
  },
  onLoad:function(options){//接收id  
    this.setData({
      yourID:options.yourID
    })
    console.log(options.yourID);
    this.getData()
},
getData:function(){
  //that全局
  let that = this
  var shopcar=""
  var scar=[]
  //从数据库中取数据
  wx.cloud.database().collection("user").doc(this.data.yourID).get({
    success:res =>{
      console.log("请求成功",res)
      that.setData({
        datalist1:res.data//用来存储该用户的信息
      })
      shopcar=this.data.datalist1.shopCar//用来存储该用户的购物车中的商品id
      console.log("看我",shopcar)
      wx.cloud.database().collection("goodList").get({
        success:res =>{
          console.log("请求成功",res)
          that.setData({
            datalist2:res.data
          })
          for (var i = 0; i < shopcar.length; i++) { 
         console.log(shopcar[i])
         console.log(this.data.datalist2[shopcar[i]])
         scar.push(this.data.datalist2[shopcar[i]])
        }
        console.log(scar)
        this.setData({
          showlist:scar
        })
      },
        fail:res =>{
          console.log("请求失败", res)
        }
      })
    },
    fail:res =>{
      console.log("请求失败", res)
    }
  })
},

//购买按钮，购买商品
goToIntroduce: function (event) {
  //获取当前item的下标id  通过currentTarget.id
  var id = event.currentTarget.id;
  this.setData({
    _id:this.data.showlist[id]._id
   })
  wx.navigateTo({
    url: '/pages/01shouye/goods/goodintroduce?_id='+this.data._id+'&yourID='+this.data.yourID
  })
},
jumpPage1: function () //返回商品类型界面
{
  wx.navigateTo({
    url: '/pages/01shouye/goods/goodType?yourID='+this.data.yourID
  })
},
  jumpPage2: function () //到达建议页面
  {
    wx.navigateTo({
      url: '/pages/01shouye/advice/giveAdvice?yourID='+this.data.yourID
    })
  }
})
