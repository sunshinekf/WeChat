// pages/01shouye/advice/giveAdvice.js
let money="";
let yourWeight=[];
let shopcar=[];
let price=[];//按照商品id顺序存储对应的价格
let goodsName=[];//储存所有商品名称
Page({
  data: {
    //传输用户id
    yourID:"",
    //储存该用户信息
    datalist:[],
    
   result:[],

   disable:true,
   disable2:true
  },
  onLoad:function(options){
    this.setData({
      yourID:options.yourID
    })
    console.log(options.yourID);
    this.showadvice()
    //this.dealData()
},
money(event) {
  this.setData({
    disable: false
  })
  money = event.detail.value
},
showadvice:function(){
  //that全局
  let that = this;

  //得到该用户的详情
  wx.cloud.database().collection("user").doc(this.data.yourID).get({
    success:res =>{
      console.log("请求成功",res)
      //将该用户全部信息存储
      that.setData({
        datalist:res.data
      })
      yourWeight=this.data.datalist.weight;//该用户的商品权重
      shopcar=this.data.datalist.shopCar;//该用户的购物车信息
      for (var i = 0; i < shopcar.length; i++) {
        wx.cloud.database().collection("goodList").doc(shopcar[i]).get({
          success:res =>{
            console.log("请求成功",res)
            
            var  goodlist=res.data
            price.push(goodlist.price)//按照商品id顺序存储对应的价格
            goodsName.push(goodlist.name)//按照商品id顺序存储对应的名称

            },
            fail:res =>{
              console.log("请求失败", res)
            }
        })  
      }
      this.setData({
        result:result
      })
      
    },
    fail:res =>{
      console.log("请求失败", res)
    }
  })

},
dealData:function(){
      this.setData({
        disable2: false
      })
      var result=[];//储存最终的排序结果
      for (var i = 0; i < shopcar.length; i++) {
        var sc=shopcar[i];
        var wei=yourWeight[i];

        //处理最终权重

        var bo=(((0.823*money-1501.180)-price[i])/money)*wei/100;
        var newarray = [{ id: sc,name:goodsName[i], price:price[i],weight:wei,both:bo}]; 
            //储存最终的排序结果
        result.push(newarray[0]) ;//把两个数组合拼起来 

            console.log("result", result)
      }

      this.setData({
        result:result
      })
      console.log("result", this.data.result)
      
},
mySort1: function (e) {//正序
  //property 根据什么排序
  var property = e.currentTarget.dataset.property;
  var self = this;
  var result = self.data.result;
  var sortRule = true; // 正序true;倒序false
  self.setData({
    result: result.sort(self.compare(property, sortRule))
  })
  //console.log(arr)
},
mySort2: function (e) {//倒序
  //property 根据什么排序
  var property = e.currentTarget.dataset.property;
  var self = this;
  var result = self.data.result;
  var sortRule = false; // 正序true;倒序false
  self.setData({
    result: result.sort(self.compare(property, sortRule))
  })
  //console.log(arr)
},
compare: function (property, bol) {
  return function (a, b) {
  var value1 = a[property];
  var value2 = b[property];
  if(bol){
    return value1 - value2;
  }else {
    return value2 - value1;
  }
}
},
jumpPage: function () //查看购物车，到达购物车页面
{
  wx.navigateTo({
    url: '/pages/01shouye/shopCar/shopCar?yourID='+this.data.yourID
  })
}
})
